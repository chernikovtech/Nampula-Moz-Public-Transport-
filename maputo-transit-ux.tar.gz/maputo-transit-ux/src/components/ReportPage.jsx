import { Link } from 'react-router-dom'

const LOGO = 'https://avatars.mds.yandex.net/get-lpc/14837328/21641dca-3288-4eeb-8d99-81f8cb31a763/orig'

const s = {
  hero: { background: '#000', color: '#fff', padding: '5rem 0 4rem', textAlign: 'center' },
  container: { maxWidth: 1100, margin: '0 auto', padding: '0 1.87rem' },
  section: { padding: '4rem 0' },
  sectionDark: { padding: '4rem 0', background: '#232323', color: '#F5F5F5' },
  label: { fontSize: '0.72rem', fontWeight: 500, textTransform: 'uppercase', letterSpacing: '0.12em', color: '#7A7A7A', marginBottom: '0.75rem', fontFamily: '"Yango Group Text", sans-serif' },
  labelDark: { fontSize: '0.72rem', fontWeight: 500, textTransform: 'uppercase', letterSpacing: '0.12em', color: 'rgba(255,255,255,0.4)', marginBottom: '0.75rem', fontFamily: '"Yango Group Text", sans-serif' },
  h2: { fontFamily: '"Yango Headline", sans-serif', fontWeight: 900, fontSize: 'clamp(1.6rem, 3.5vw, 2.5rem)', lineHeight: '90%', letterSpacing: 'calc(1em/50)', textTransform: 'uppercase', marginBottom: '1.5rem' },
  h3: { fontFamily: '"Yango Headline", sans-serif', fontWeight: 900, fontSize: 'clamp(1.2rem, 2vw, 1.5rem)', lineHeight: '90%', letterSpacing: 'calc(1em/50)', textTransform: 'uppercase', marginTop: '2rem', marginBottom: '1rem' },
  card: { background: '#fff', borderRadius: '1.875rem', padding: '2rem', marginBottom: '1.5rem' },
  cardDark: { background: '#323232', borderRadius: '1.875rem', padding: '2rem', marginBottom: '1.5rem' },
  prose: { maxWidth: 760, lineHeight: 1.8, letterSpacing: '0.05em' },
  tag: { display: 'inline-block', fontSize: '0.65rem', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.1em', padding: '0.25rem 0.7rem', borderRadius: '2rem', marginRight: '0.3rem', marginBottom: '0.3rem' },
  stat: { background: '#fff', borderRadius: '1.25rem', padding: '1.25rem', textAlign: 'center' },
  statVal: { fontFamily: '"Yango Headline", sans-serif', fontWeight: 900, fontSize: '1.8rem', lineHeight: 1, color: '#FF1A1A' },
  statLabel: { fontSize: '0.68rem', fontWeight: 500, textTransform: 'uppercase', letterSpacing: '0.12em', color: '#7A7A7A', marginTop: '0.25rem', fontFamily: '"Yango Group Text", sans-serif' },
  demoBtn: { display: 'inline-flex', alignItems: 'center', gap: '0.5rem', borderRadius: '2rem', padding: '0.7rem 1.25rem', fontSize: '0.72rem', fontWeight: 500, letterSpacing: '0.12em', textTransform: 'uppercase', textDecoration: 'none', fontFamily: '"Yango Group Text", sans-serif', transition: 'opacity 0.2s', marginTop: '1rem' },
}

function Stat({ value, label }) {
  return (
    <div style={s.stat}>
      <div style={s.statVal}>{value}</div>
      <div style={s.statLabel}>{label}</div>
    </div>
  )
}

function Tag({ children, color }) {
  const colors = {
    red: { background: 'rgba(255,26,26,0.1)', color: '#FF1A1A' },
    green: { background: 'rgba(16,185,129,0.1)', color: '#059669' },
    blue: { background: 'rgba(79,70,229,0.1)', color: '#4F46E5' },
    amber: { background: 'rgba(245,158,11,0.1)', color: '#D97706' },
  }
  return <span style={{ ...s.tag, ...(colors[color] || colors.red) }}>{children}</span>
}

function EdgeTable({ rows, dark }) {
  const thStyle = { background: '#232323', color: '#fff', fontSize: '0.72rem', fontWeight: 500, textTransform: 'uppercase', letterSpacing: '0.12em', padding: '0.85rem 1rem', textAlign: 'left', fontFamily: '"Yango Group Text", sans-serif' }
  const tdStyle = { padding: '0.75rem 1rem', borderBottom: '1px solid #F5F5F5', fontSize: '0.82rem', verticalAlign: 'top', background: dark ? '#323232' : '#fff', color: dark ? '#F5F5F5' : '#141414' }
  return (
    <div style={{ overflowX: 'auto', marginTop: '1rem' }}>
      <table style={{ width: '100%', borderCollapse: 'separate', borderSpacing: 0, borderRadius: '1.25rem', overflow: 'hidden' }}>
        <thead>
          <tr>
            <th style={{ ...thStyle, width: 160 }}>Scenario</th>
            <th style={thStyle}>Response</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i}>
              <td style={{ ...tdStyle, fontWeight: 600, whiteSpace: 'nowrap' }}>{r[0]}</td>
              <td style={tdStyle}>{r[1]}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

export default function ReportPage() {
  return (
    <div>
      {/* HERO */}
      <section style={s.hero}>
        <div style={s.container}>
          <div style={{ ...s.tag, background: 'rgba(255,255,255,0.08)', color: 'rgba(255,255,255,0.5)', marginBottom: '1.5rem' }}>
            Yango Tech · Smart City · Public Transport
          </div>
          <h1 style={{ fontFamily: '"Yango Headline", sans-serif', fontWeight: 900, fontSize: 'clamp(2.2rem, 5vw, 3.5rem)', lineHeight: '88%', letterSpacing: 'calc(1em/50)', textTransform: 'uppercase', marginBottom: '1.25rem' }}>
            Maputo Transit<br />UX Design Concepts
          </h1>
          <p style={{ fontSize: '0.95rem', color: 'rgba(255,255,255,0.55)', maxWidth: 700, margin: '0 auto', letterSpacing: '0.05em' }}>
            Three mobile ticketing and bus navigation system concepts for Mozambique's Maputo metropolitan area — designed for the Move Maputo BRT deployment, the FAMBA electronic ticketing ecosystem, and the 350+ cooperative buses serving 3 million citizens.
          </p>
        </div>
      </section>

      {/* STATS */}
      <section style={s.section}>
        <div style={s.container}>
          <div style={s.label}>Market Context</div>
          <h2 style={s.h2}>The Maputo Challenge</h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: '0.75rem', marginBottom: '1.5rem' }}>
            <Stat value="3M" label="Metro Population" />
            <Stat value="739" label="Total Buses" />
            <Stat value="13" label="Active Routes" />
            <Stat value="128K" label="Daily Passengers" />
            <Stat value="$250M" label="World Bank Grant" />
            <Stat value="0%" label="Digital Infrastructure" />
          </div>
          <div style={s.prose}>
            <p>Maputo's transport ecosystem presents a paradox: a $250M World Bank-funded BRT system is being built alongside an entirely informal, cash-based, unmonitored fleet of 715 private minibuses. The FAMBA card system — a PPP for electronic fare collection — was rolled out in 2021 but adoption stalled. The municipality's first priority is simple: <strong>track buses to detect driver malpractice in route cutting and fare skimming</strong>.</p>
          </div>
        </div>
      </section>

      {/* CONCEPT 1 */}
      <section style={s.sectionDark} id="concept-1">
        <div style={s.container}>
          <div style={s.labelDark}>Concept 01</div>
          <div style={{ ...s.cardDark, borderLeft: '5px solid #E85D04', paddingLeft: '1.75rem', position: 'relative', overflow: 'hidden' }}>
            <div style={{ position: 'absolute', top: '-0.5rem', right: '1rem', fontFamily: '"Yango Headline"', fontWeight: 900, fontSize: '5rem', lineHeight: 1, color: '#E85D04', opacity: 0.08 }}>01</div>
            <div style={{ fontFamily: '"Yango Headline"', fontWeight: 900, fontSize: '1.6rem', lineHeight: '90%', textTransform: 'uppercase', color: '#E85D04', marginBottom: '0.3rem' }}>Famba Digital</div>
            <div style={{ fontSize: '0.9rem', color: '#E85D04', fontWeight: 500, marginBottom: '1rem' }}>Bridge the cash gap — meet users where they are</div>
            <div style={{ ...s.prose, color: 'rgba(255,255,255,0.65)' }}>
              <p>Famba Digital accepts that Maputo's transit is cash-first and builds a digital layer on top without forcing behavior change. Every cash payment generates a digital receipt. The USSD channel (*321#) works on any phone without data. The smartphone app is a bonus layer, not a prerequisite. The system digitizes revenue from day one while passengers barely notice the transition.</p>
            </div>
            <div style={{ marginTop: '0.75rem' }}>
              <Tag color="amber">Cash-First</Tag>
              <Tag color="amber">USSD Fallback</Tag>
              <Tag color="amber">Conductor-Assisted</Tag>
              <Tag color="amber">FAMBA Card Integration</Tag>
            </div>
            <Link to="/concept-1" style={{ ...s.demoBtn, background: '#E85D04', color: '#fff' }}>
              Launch Interactive Demo →
            </Link>
          </div>

          <h3 style={{ ...s.h3, color: '#fff' }}>Workflow Narrative</h3>
          <div style={{ ...s.prose, color: 'rgba(255,255,255,0.65)' }}>
            <p><strong style={{ color: '#fff' }}>Route Discovery:</strong> Passengers discover routes via physical QR signage at stops, USSD *321# for SMS schedule delivery, or the app's route browser with offline-cached schedules and live GPS overlays.</p>
            <p><strong style={{ color: '#fff' }}>Boarding & Payment:</strong> Three simultaneous paths: (a) Cash — conductor taps "cash fare" on ruggedized handheld, optional QR paper receipt printed; (b) FAMBA Card — NFC tap on conductor's reader; (c) USSD — passenger shows SMS code (FMB-XXXX) after paying via M-Pesa through *321#.</p>
            <p><strong style={{ color: '#fff' }}>Route Monitoring:</strong> GPS trackers (mandatory for license renewal) transmit position continuously. If bus deviates 200m+ from route corridor for 60+ seconds, automatic alert fires to AMT dispatch. This is the core anti-fraud mechanism.</p>
            <p><strong style={{ color: '#fff' }}>Transfer:</strong> 90-minute validity window allows free transfer. Second conductor scans QR/FAMBA and recognizes existing valid ticket. Works across BRT, cooperatives, and CFM rail.</p>
            <p><strong style={{ color: '#fff' }}>Post-Trip:</strong> AMT dashboard aggregates fare revenue per route, passenger counts per stop, GPS compliance scores per driver, and peak-hour load factors.</p>
          </div>

          <h3 style={{ ...s.h3, color: '#fff' }}>Edge Cases</h3>
          <EdgeTable dark rows={[
            ['No smartphone', 'USSD *321# on any phone. Cash with paper receipt. Feature phone SMS confirmations.'],
            ['No data/offline', 'App caches routes offline. USSD needs zero data. Conductor device syncs when back in coverage.'],
            ['Phone dies', 'QR paper receipt is fallback. FAMBA card always valid. Conductor stores validation record.'],
            ['Transfer', '90-min ticket window. QR/FAMBA recognized across all AMT operators.'],
            ['Disputed fare', 'Digital receipt (SMS/app) = proof. Conductor device logs all transactions.'],
            ['Subsidy', 'Red FAMBA cards auto-apply subsidy. Student verification via school registration.'],
            ['First-time user', '50+ FAMBA registration booths. App: 3-step onboarding. USSD: zero onboarding.'],
            ['Driver fraud', 'GPS geofencing detects route cutting in 60s. Passenger count vs. revenue reconciliation.'],
          ]} />
        </div>
      </section>

      {/* CONCEPT 2 */}
      <section style={s.section} id="concept-2">
        <div style={s.container}>
          <div style={s.label}>Concept 02</div>
          <div style={{ ...s.card, borderLeft: '5px solid #0D9488', paddingLeft: '1.75rem', position: 'relative', overflow: 'hidden' }}>
            <div style={{ position: 'absolute', top: '-0.5rem', right: '1rem', fontFamily: '"Yango Headline"', fontWeight: 900, fontSize: '5rem', lineHeight: 1, color: '#0D9488', opacity: 0.07 }}>02</div>
            <div style={{ fontFamily: '"Yango Headline"', fontWeight: 900, fontSize: '1.6rem', lineHeight: '90%', textTransform: 'uppercase', color: '#0D9488', marginBottom: '0.3rem' }}>Mover</div>
            <div style={{ fontSize: '0.9rem', color: '#0D9488', fontWeight: 500, marginBottom: '1rem' }}>Leapfrog cards — mobile money is the ticket</div>
            <div style={s.prose}>
              <p>Mover treats mobile money (M-Pesa, e-Mola, Mkesh) as the primary fare payment rail. Your phone number is your transit account. The USSD shortcode *234# becomes the universal ticket machine. The app adds multimodal journey planning across BRT, chapa, and CFM rail with a single fare for the whole journey.</p>
            </div>
            <div style={{ marginTop: '0.75rem' }}>
              <Tag color="green">Mobile Money Native</Tag>
              <Tag color="green">Multimodal</Tag>
              <Tag color="green">Single Daily Fare</Tag>
              <Tag color="green">Account-Based Ticketing</Tag>
            </div>
            <Link to="/concept-2" style={{ ...s.demoBtn, background: '#0D9488', color: '#fff' }}>
              Launch Interactive Demo →
            </Link>
          </div>

          <h3 style={s.h3}>Workflow Narrative</h3>
          <div style={s.prose}>
            <p><strong>Route Discovery:</strong> AI learns patterns — after 3 trips from the same origin, suggests "Home → Work." Shows all modes ranked by time, cost, transfers. USSD *234# press 1 = "My usual trip" via SMS.</p>
            <p><strong>Payment:</strong> App initiates mobile money payment via integrated M-Pesa/e-Mola API. SMS code (MOV-XXXX) arrives in 5 seconds — this is the ticket. USSD *234*[amount]*[route]# for non-smartphone. Single charge covers entire multimodal journey.</p>
            <p><strong>Validation:</strong> SMS code or QR shown to conductor/station validator. System marks each leg as completed. Same code validates across all operators — no re-payment.</p>
            <p><strong>Revenue:</strong> All money flows through mobile money clearing — no cash. Each operator gets share based on passenger-km from GPS data. Pooled revenue eliminates skimming incentive.</p>
          </div>

          <h3 style={s.h3}>Edge Cases</h3>
          <EdgeTable rows={[
            ['No smartphone', 'USSD *234# is primary interface. 100% functional. SMS ticket codes work for validation.'],
            ['No data/offline', 'USSD needs zero data. App downloads plans offline. SMS codes work without connectivity.'],
            ['Phone dies', 'SMS code already received — recite to conductor. FAMBA card fallback always available.'],
            ['Transfer', 'Single multimodal fare covers all legs. Same code validates across BRT, chapa, CFM.'],
            ['Disputed fare', 'Complete mobile money transaction trail is irrefutable proof.'],
            ['Subsidy', 'Phone number linked to subsidy registry. Discounted fare auto-applies.'],
            ['First-time user', 'Any phone that can dial USSD is ready. App: link one wallet, done.'],
            ['Driver fraud', 'Cashless by design — driver never touches money. GPS compliance scoring continuous.'],
          ]} />
        </div>
      </section>

      {/* CONCEPT 3 */}
      <section style={s.sectionDark} id="concept-3">
        <div style={s.container}>
          <div style={s.labelDark}>Concept 03</div>
          <div style={{ ...s.cardDark, borderLeft: '5px solid #4F46E5', paddingLeft: '1.75rem', position: 'relative', overflow: 'hidden' }}>
            <div style={{ position: 'absolute', top: '-0.5rem', right: '1rem', fontFamily: '"Yango Headline"', fontWeight: 900, fontSize: '5rem', lineHeight: 1, color: '#4F46E5', opacity: 0.08 }}>03</div>
            <div style={{ fontFamily: '"Yango Headline"', fontWeight: 900, fontSize: '1.6rem', lineHeight: '90%', textTransform: 'uppercase', color: '#4F46E5', marginBottom: '0.3rem' }}>Xitimela</div>
            <div style={{ fontSize: '0.9rem', color: '#4F46E5', fontWeight: 500, marginBottom: '1rem' }}>Community intelligence — passengers and drivers build the map together</div>
            <div style={{ ...s.prose, color: 'rgba(255,255,255,0.65)' }}>
              <p>"Xitimela" means "to wait for transport" in Changana. This concept crowdsources real-time intelligence from the community. Passengers report where buses are, drivers announce departures, and the network self-organizes. A gamified reputation system incentivizes honest reporting and penalizes driver fraud through social accountability.</p>
            </div>
            <div style={{ marginTop: '0.75rem' }}>
              <Tag color="blue">Community-Powered</Tag>
              <Tag color="blue">Crowdsourced Data</Tag>
              <Tag color="blue">Gamified Trust</Tag>
              <Tag color="blue">Driver Reputation</Tag>
            </div>
            <Link to="/concept-3" style={{ ...s.demoBtn, background: '#4F46E5', color: '#fff' }}>
              Launch Interactive Demo →
            </Link>
          </div>

          <h3 style={{ ...s.h3, color: '#fff' }}>Workflow Narrative</h3>
          <div style={{ ...s.prose, color: 'rgba(255,255,255,0.65)' }}>
            <p><strong style={{ color: '#fff' }}>Route Discovery:</strong> Live community feed instead of static schedules. Passengers report sightings ("Chapa 7 left Xipamanine, 8 seats"). Drivers announce departures. Reports verified by other users — confirmations earn reputation points.</p>
            <p><strong style={{ color: '#fff' }}>Payment:</strong> All methods supported, but digital earns 5 bonus points. Points unlock badges and eventually fare discounts. Gamification drives digital adoption without coercion.</p>
            <p><strong style={{ color: '#fff' }}>Anti-Fraud:</strong> Community-powered detection requires 3+ passenger confirmations. Drivers with persistent violations see public reputation drop. A 3.2-rated driver loses passengers to a 4.7-rated driver on the same route.</p>
          </div>

          <h3 style={{ ...s.h3, color: '#fff' }}>Edge Cases</h3>
          <EdgeTable dark rows={[
            ['No smartphone', 'WhatsApp groups (feature phone). USSD *567# for tickets. SMS alerts for saved routes.'],
            ['No data/offline', 'Cached community reports. SMS-based reporting. Retroactive ratings when back online.'],
            ['Phone dies', 'Check-in recorded at boarding. Auto-completed when phone reconnects via location delta.'],
            ['Transfer', 'Community reports indicate shortest waits. Ticket validity window handles fare integration.'],
            ['Disputed fare', 'Pattern evidence from community. 10+ overcharging reports = auto-investigation.'],
            ['Subsidy', 'FAMBA concessions + community "solidarity points" donated by other commuters.'],
            ['First-time user', 'WhatsApp group invite shared via social networks. No account to view feed.'],
            ['Driver fraud', 'Crowdsourced detection (3+ confirmations). Public reputation scores. Market-driven accountability.'],
          ]} />
        </div>
      </section>

      {/* COMPARISON MATRIX */}
      <section style={s.section} id="comparison">
        <div style={s.container}>
          <div style={s.label}>Analysis</div>
          <h2 style={s.h2}>Comparison Matrix</h2>
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'separate', borderSpacing: 0, borderRadius: '1.25rem', overflow: 'hidden', fontSize: '0.8rem' }}>
              <thead>
                <tr>
                  {['Dimension', '01 · Famba Digital', '02 · Mover', '03 · Xitimela'].map((h, i) => (
                    <th key={i} style={{ background: '#232323', color: '#fff', fontSize: '0.68rem', fontWeight: 500, textTransform: 'uppercase', letterSpacing: '0.12em', padding: '0.85rem 0.75rem', textAlign: 'left', fontFamily: '"Yango Group Text", sans-serif' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {[
                  ['Adoption Speed', ['5', 'Zero behavior change'], ['4', 'Mobile money widespread'], ['3', 'Needs community building']],
                  ['Technical Complexity', ['4', 'Moderate — conductor devices + GPS'], ['3', 'High — mobile money APIs + clearing'], ['4', 'Moderate — community platform']],
                  ['Operator Buy-In', ['4', 'Cash still flows, GPS mandated'], ['2', 'Cashless = resistance from chapas'], ['3', 'Good drivers benefit, bad resist']],
                  ['Inclusivity', ['5', 'Works with no phone at all'], ['4', 'USSD works, needs mobile money'], ['3', 'App-centric for full experience']],
                  ['Revenue Leakage', ['3', 'GPS good, cash still leaks'], ['5', 'Cashless by design, full audit'], ['4', 'Community detection, reactive']],
                  ['Donor Alignment', ['4', 'Pragmatic, phased approach'], ['5', 'Single-fare multimodal = WB vision'], ['3', 'Innovative but less controllable']],
                ].map((row, i) => (
                  <tr key={i}>
                    <td style={{ padding: '0.7rem 0.75rem', borderBottom: '1px solid #F5F5F5', fontWeight: 600, whiteSpace: 'nowrap', background: '#fff' }}>{row[0]}</td>
                    {[1, 2, 3].map(c => (
                      <td key={c} style={{ padding: '0.7rem 0.75rem', borderBottom: '1px solid #F5F5F5', background: '#fff', verticalAlign: 'top' }}>
                        <span style={{ display: 'inline-block', width: 26, height: 26, borderRadius: 7, textAlign: 'center', lineHeight: '26px', fontWeight: 700, fontSize: '0.72rem', color: '#fff', background: row[c][0] >= 5 ? '#10B981' : row[c][0] >= 4 ? '#34D399' : row[c][0] >= 3 ? '#FBBF24' : '#F97316', marginRight: 8 }}>{row[c][0]}</span>
                        <span style={{ color: '#7A7A7A' }}>{row[c][1]}</span>
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Totals */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '0.75rem', marginTop: '1.5rem' }}>
            {[
              { name: 'Famba Digital', score: '25/30', color: '#E85D04' },
              { name: 'Mover', score: '23/30', color: '#0D9488' },
              { name: 'Xitimela', score: '20/30', color: '#4F46E5' },
            ].map((c, i) => (
              <div key={i} style={{ ...s.stat }}>
                <div style={{ ...s.statVal, color: c.color }}>{c.score}</div>
                <div style={s.statLabel}>{c.name}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* RECOMMENDATION */}
      <section style={s.sectionDark} id="recommendation">
        <div style={s.container}>
          <div style={s.labelDark}>Strategic Recommendation</div>
          <h2 style={{ ...s.h2, color: '#fff' }}>Phased Rollout Plan</h2>
          <div style={{ ...s.cardDark, borderLeft: '5px solid #FF1A1A', paddingLeft: '1.75rem' }}>
            <h3 style={{ ...s.h3, marginTop: 0, color: '#FF1A1A' }}>Verdict: Start with Famba Digital, Evolve into Mover</h3>
            <div style={{ ...s.prose, color: 'rgba(255,255,255,0.65)' }}>
              <p>Famba Digital is the right starting concept because it solves the immediate priority — GPS route monitoring and revenue visibility — without requiring behavioral change. Cash still works. The conductor keeps their role. But behind the scenes, every trip is digitized.</p>
            </div>
          </div>

          {[
            { phase: 'P1', color: '#E85D04', title: 'Phase 1: Famba Digital Foundation', time: 'Months 1–6 · $80K–$120K', desc: 'Deploy GPS trackers on all 739 buses. Roll out conductor handhelds on public buses first. Launch USSD *321# for schedules and tickets. Build AMT compliance dashboard. Goal: 100% GPS coverage.' },
            { phase: 'P2', color: '#0D9488', title: 'Phase 2: Mover Migration', time: 'Months 6–18 · Aligned with BRT Launch', desc: 'Introduce multimodal journey planner and mobile money rails when BRT corridors come online. Implement revenue pooling for BRT routes. Integrate CFM rail. Begin cashless migration on high-compliance routes.' },
            { phase: 'P3', color: '#4F46E5', title: 'Phase 3: Community Layer', time: 'Months 18–36 · Full Ecosystem', desc: "Layer Xitimela's community features — crowdsourced reporting, driver reputation, community groups — on top of the now-digitized system. By this point, enough users have digital habits to sustain the platform." },
          ].map((p, i) => (
            <div key={i} style={{ ...s.cardDark, display: 'flex', gap: '1rem', alignItems: 'flex-start' }}>
              <div style={{ width: 44, height: 44, borderRadius: 22, background: p.color, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontFamily: '"Yango Headline"', fontWeight: 900, fontSize: '1rem', flexShrink: 0 }}>{p.phase}</div>
              <div>
                <div style={{ fontWeight: 600, fontSize: '0.95rem', color: '#fff' }}>{p.title}</div>
                <div style={{ fontSize: '0.75rem', color: 'rgba(255,255,255,0.4)', marginBottom: '0.5rem', fontFamily: '"Yango Group Text", sans-serif' }}>{p.time}</div>
                <p style={{ color: 'rgba(255,255,255,0.6)', lineHeight: 1.7 }}>{p.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* FOOTER */}
      <section style={{ background: '#000', padding: '2.5rem 0', textAlign: 'center' }}>
        <img src={LOGO} alt="Yango Tech" style={{ filter: 'invert(1)', height: 22, marginBottom: '0.75rem' }} />
        <p style={{ color: 'rgba(255,255,255,0.35)', fontSize: '0.72rem', letterSpacing: '0.05em' }}>Maputo Transit UX Concepts · Yango Tech Smart City Division · March 2026</p>
        <p style={{ color: 'rgba(255,255,255,0.2)', fontSize: '0.62rem', letterSpacing: '0.05em', marginTop: '0.3rem' }}>Prepared for Nampula Municipality / AMT · Confidential</p>
      </section>
    </div>
  )
}
